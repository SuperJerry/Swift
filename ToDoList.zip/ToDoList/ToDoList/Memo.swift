//
//  Memo.swift
//  ToDoList
//
//  Created by Jerry on 7/24/15.
//  Copyright (c) 2015 Jerry. All rights reserved.
//

import Foundation
class Memo {
    
    var title: String!
    var description: String!
    
    
    init(passtitle: String, passdescription: String){
        title = passtitle
        description = passdescription
    }
}
